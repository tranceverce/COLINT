function Myfooter() {
  return (
    <div style={{
      backgroundColor:'black',
      color:'white',
      position:'fixed',
      bottom: 0,
      textAlign:"center",
      width:'100%'
    }}>
      <h5>&copy; Mansi Varshney 2023</h5>
    </div>
  );
}

export default Myfooter;
